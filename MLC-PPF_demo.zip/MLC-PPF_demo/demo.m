%clear
%clc
%%%%%  test on morning rush period %%%%


load('Area_data.mat')
load('DM.mat')
load('ABS_data')

ratio = 0.2; % The proportion of target areas.
targetD = 2;
F = Area{1,end}; % target day
n = size(F,1);

test = randperm(n,round(n*ratio));

Y = ones(n);
Y(test,:)=0;
Y(:,test)=0;


X{1} = Economy;
X{2} = Family;
X{3} = Income;
X{4} = Population;

id = test;


Topk = 2;

lambda = 0.1;



[H,X_k] = build_X_knn(F,X,DM,Topk,id);


F_pre = getPre(Y,Area,X,H,X_k,lambda);

F_pre = F_pre{targetD};

F_pre = F_pre(id,:);




[MAE,NRMSE] = getMAE(F_pre,F(id,:),id)


function obj = getobj(Y,F,H,W,C,X,X_k,lambda)

    obj = (norm(Y.*(F{1}-(H.*W)*F{1}*C),'fro').^2 + norm(Y.*(F{2}-(H.*W)*F{2}*C),'fro').^2 + lambda*((norm(X{1}-C*X_k{1},'fro').^2)+(norm(X{2}-C*X_k{2},'fro').^2)...
        +(norm(X{3}-C*X_k{3},'fro').^2)+(norm(X{4}-C*X_k{4},'fro').^2)))./(4*size(Y,1)*size(Y,1));
end




function F = getPre(Y,A,X,H,X_k,lambda)


    F = A;
    M = A;
    W = ones(size(F{1},1));
    C = pinv(Y.*((H.*W)*F{end}))*(Y.*F{end});
    
    for d = 1:size(F,2)
        F{d} = Y.* M{d} + (1-Y).*(((H.*W)*F{d})*C);
    end
    
    
    Y(logical(eye(size(F{1},1))))=0;
    
    step = 10^-1;
    error = 10^-5;
    
    obj_old = getobj(Y,F,H,W,C,X,X_k,lambda);
    
    for Iter = 1 : 100
        
        O1 = 0;
        O2 = 0;
        O3 = 0;
        
        for d = 1:size(F,2)
            O1 = O1 - ((H.*W)*F{d})'*(F{d}-((H.*W)*F{d})*C);
        end
        for v = 1:size(X_k,2)
            O2 = O2 - lambda*(X{v}*X_k{v}') + lambda*(C*X{v}*X_k{v}');
        end
        
        gC = O1 + O2;
        
        C = C - (step*2).* gC./(norm(gC,'fro'));
        
        for d = 1:size(F,2)
            O3 = O3 -H.*(F{d}*C'*F{d}') + (H.*W)*F{d}*C*C'*F{d}';
        end
               
        gW = O3;
        
        W = W - (step).* gW./norm(gW,'fro');
        
        for d = 1:size(F,2)
            F{d} = Y.* M{d} + (1-Y).*(((H.*W)*F{d})*C);
        end
        
        obj_new = getobj(Y,F,H,W,C,X,X_k,lambda);
        
        if abs(obj_new-obj_old)/(obj_old) < error
            break
        end
        obj_old = obj_new;
    end
    

end


function [H,X_k] = build_X_knn(F0,X0,DM0,Topk0,id0)
    n = size(F0,1);
    F_k = zeros(n);
    H = zeros(n);
    for j = 1:size(X0,2)
        m(j) = size(X0{j},2);        
        X_k{j} = zeros(n,m(j));
    end    
    
    for i = 1:length(id0)
        DM0(DM0==id0(i)) = 0;
    end
        

    DM0(:,1)=[];
    
    DM_new = zeros(size(DM0,1),Topk0);
    
    for i = 1:n
        vec = DM0(i,:);
        y = find(vec==0);
        if isempty(y)
            vec = vec(1:Topk0);
        else
            vec(y) = [];
            vec = vec(1:Topk0);
            
        end
        DM_new(i,:) = vec;
    end
    
    
    for k = 1:size(X0,2)
        for i = 1:n
            for j = 1:Topk0
                if k==1
                    F_k(i,:) = F_k(i,:) + F0(DM_new(i,j),:);
                    X_k{k}(i,:) = X_k{k}(i,:) + X0{k}(DM_new(i,j),:);
                else
                    X_k{k}(i,:) = X_k{k}(i,:) + X0{k}(DM_new(i,j),:);
                end
            end
        end
    end
        
    
    
    for q = 1:n
        h = zeros(1,n);
        h(DM_new(q)) = 1;
        H(q,:) = h;
    end
    
    X_k = X_k;
    F_k = F_k;
    
end

function [MAE,NRMSE] = getMAE(pre,gt,m)

    pre(pre<0)=0;
    pre(:,m)=0;
    pre = round(pre);
    gt(:,m)=0;
    
    
    Err1 = abs(pre-gt);
    Err2 = abs(pre-gt).^2;
    MAE = sum(Err1(:))/(size(gt,1)*size(gt,2));
    NRMSE = 100*sqrt(sum(Err2(:))/(size(gt,1)*size(gt,2)))/max(gt(:));

end



