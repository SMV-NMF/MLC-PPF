load('maplist.mat')
load('missId.mat')

for k = 7:24
    
    dataIn = IN_1107(:,:,k);
    dataOut = OUT_1107(:,:,k);
    AreaIn = zeros(182,182);
    AreaOut = zeros(182,182);
    
    
    for i = 1:size(dataIn,1)
        for j = 1:size(dataIn,1)
            AreaIn(maplist(i),maplist(j)) = AreaIn(maplist(i),maplist(j)) + dataIn(i,j);
            AreaOut(maplist(i),maplist(j)) = AreaOut(maplist(i),maplist(j)) + dataOut(i,j);
        end
    end
    
    AreaM_In(:,:,k-6) = AreaIn;
    AreaM_Out(:,:,k-6) = AreaOut;
    
end

Flow = zeros(182,36);

for i = 1 : 18
    in = diag(AreaM_In(:,:,i));
    out = diag(AreaM_Out(:,:,i));
    Flow(:,i*2-1) = in;
    Flow(:,i*2) = out;
end








