
load('timespan1hour.mat','span')
%load('timespan10.mat');
%span = timespan10;

%data = ReadD(data1,data2,data3);

Ttapon = data(:,2);
Ttapoff = data(:,3);

for i = 1:24
    if i<24
        P = find(Ttapon>=span(i)&Ttapon<span(i+1));
    else
        P = find(Ttapon>=span(i));
    end
    M_in = zeros(194);
%    M_in = zeros(178);
    M_out = zeros(194);
%    M_out = zeros(178);

    listIn = unique(data(P,4));
        for j1 = 1:length(listIn)
        
            p1=find(data(P,4)==listIn(j1));%
            M_in(listIn(j1),listIn(j1)) = length(p1);
            uni = unique(data(P(p1),5));%
            if length(uni)==1
                M_in(listIn(j1),uni) = length(p1);
            else
                count = hist(data(P(p1),5),uni); %
                M_in(listIn(j1),uni) = count;
            end
        end
        
%         for j2 = 1:length(listIn)
%         
%             p1=find(data(P,4)==listIn(j2));
% 
%             uni = unique(data(P(p1),5));
%             for k = 1:length(uni)
%                 p2=find(data(P(p1),5)==uni(k));
%                 z = P(p1(p2));
%                 cost = mean(data(P(p1(p2)),1));
%                 M_in_time(listIn(j2),uni(k)) = cost;
%             end
% 
%         end
     if i<24
          Q = find(Ttapoff>=span(i)&Ttapoff<span(i+1));
     else
          Q = find(Ttapoff>=span(i));
     end
     listOut = unique(data(Q,5));
        for j3 = 1:length(listOut)
        
            p1=find(data(Q,5)==listOut(j3));
            M_out(listOut(j3),listOut(j3)) = length(p1);
            uni = unique(data(Q(p1),4));
            if length(uni)==1
                M_out(listOut(j3),uni) = length(p1);
            else
                count = hist(data(Q(p1),4),uni); 
                M_out(listOut(j3),uni) = count;
            end
        end
        
%         for j4 = 1:length(listOut)
%         
%             p1=find(data(Q,5)==listOut(j4));
% 
%             uni = unique(data(Q(p1),4));
%             for k = 1:length(uni)
%                 p2=find(data(Q(p1),4)==uni(k));
%                 cost = mean(data(Q(p1(p2)),1));
%                 M_out_time(listOut(j4),uni(k)) = cost;
%             end
% 
%        end
           
     IN_1107(:,:,i) = M_in;
%     IN_TIME_1121(:,:,i) = M_in_time;
     OUT_1107(:,:,i) = M_out;
%     OUT_TIME_1121(:,:,i) = M_out_time;
end