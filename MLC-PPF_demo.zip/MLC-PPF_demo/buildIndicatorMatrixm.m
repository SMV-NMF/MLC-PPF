
load('missId')

% M = ones(size(Area,1));
% %M = M-diag(diag(M));
% 
% for i = 1:size(missId)
%     M(missId(i),:) = 0;
%     M(:,missId(i)) = 0;    
% end
%     
% Area(Area==0) = 0.01;
% 
% Area = Area.*M;


M = ones(size(Flow,1),size(Flow,2));
%M = M-diag(diag(M));

for i = 1:size(missId)
    M(missId(i),:) = 0;    
end
    
Flow(Flow==0) = 0.001;

Flow = Flow.*M;